# Report #2831902: [CRITICAL] 0-Click Account Takeover via Password Reset [AUTH-3243] /orchestrator/v1/password_reset/start

- **Platform:** HackerOne
- **Report URL:** [https://hackerone.com/reports/2831902](https://hackerone.com/reports/2831902)
- **Program:** Remitly
- **Reporter:** @db3wy
- **Status:** RESOLVED
- **Severity:** critical
- **Weakness:** Improper Access Control - Generic
- **Bounty:** Yes (Undisclosed Amount)
- **Submitted:** 2024-11-10T14:56:28.557Z
- **Disclosed:** 2025-07-21T22:23:32.299Z
- **Community Upvotes:** 285

---

## Executive Summaries

No formal disclosure summary provided.

---

## Full Vulnerability Description & Technical Reproduction Steps

## Summary:
A 0-click Account Takeover vulnerability was identified in the password reset functionality of the target website. This flaw allows an attacker to reset the victim's password without any interaction or consent from the victim, leading to a complete compromise of the victim's account.


## Operating System
WINDOWS


## do you use a vpn? if so which one?
NO
## Browser
FIRFOX FOR ATTACKER
Burp Browser for victim


## Steps To Reproduce:
1-----Go to the Password Reset Page:

2-----Navigate to the "Forgot Password" or "Reset Password" section on the website.
         Initiate Password Reset for Both the Victim and the Attacker Account:

3----Enter the victim's email address in the password reset form.
       Also, enter your email address (attacker's email) to initiate a password reset.
         Capture the Password Reset Request:

4-----Intercept the HTTP request using a proxy tool like Burp Suite or OWASP ZAP when submitting the password reset request.


            Analyze the Leaked Information:

To clarify:

Endpoint: /orchestrator/v1/password_reset/start

You need to obtain the JWT token from this specific endpoint.
There are two endpoints with the same name:
One endpoint does not include a JWT token in its response.
The other endpoint includes a JWT token, which is necessary for the attack.
Make sure to target the correct endpoint that provides the JWT token during the password reset process.

Any JWT token belonging to the victim from any other endpoint will not work.

Download a tool for Burp Suite called JSON Web Token. It will make your work easier as it highlights the requests containing the JWT token in green, helping you easily identify the correct endpoint

Only the mentioned 
endpoint /orchestrator/v1/password_reset/start is valid and works for obtaining the necessary JWT for the attack.

This endpoint may not appear on the first attempt; you may need to repeat the process.
As you can see in the recorded video, it appeared for me on the second attempt.





Check the intercepted request and identify sensitive parameters such as:
     AMP_d0cf3ed24c: Contains user information like deviceId, userId, and sessionId.
JWT: JSON Web Token containing the user's email and other information.



save this 2 paramter




5------Enter the One-Time Password (OTP) received on your email or phone to proceed with the password reset.-->>  attacker account
         Modify the HTTP Request:

6------Before sending the password reset request, replace your session data with the victim's session data in the HTTP request:
         Replace the """"AMP_d0cf3ed24c and JWT""""" values with the victim's values obtained from the leaked request.


7--------- Send the Modified Request:


8---Access the Victim's Account:

If successful, you will be able to reset the victim’s password without any interaction from the victim.
Log in using the victim's email address and the new password you have set.



## POC
████
█████

## Impact

##Summary:
The vulnerability discovered allows an attacker to reset the password of a victim's account without requiring any user interaction or special privileges. By intercepting the password reset request and modifying it with the victim's session data, the attacker can successfully take over the account. Additionally, the site allows money transfers, and by exploiting this vulnerability, the attacker can potentially steal funds from victims' accounts.

##Requirements:
Access to the victim's password reset request: Intercepted via tools like Burp Suite or OWASP ZAP.
Knowledge of the victim's session information: This includes tokens such as AMP_d0cf3ed24c and JWT, which are available in the intercepted requests.
Access to the attacker’s own OTP (One-Time Password): The attacker needs their own OTP for the password reset.
Ability to modify HTTP requests: The attacker needs the ability to replace their own session data with the victim’s session data to perform the attack.
##Gained Privilege:
By exploiting this vulnerability, the attacker gains the following privileges:

Full Account Control: The attacker can reset the victim’s password and log in to the account without needing the victim’s credentials.

Access to Confidential Data: The attacker gains access to sensitive information within the victim’s account, including personal details, emails, and other private data.

Manipulation of Account Settings: The attacker can modify account settings, change the email address associated with the account, or perform other actions that would typically require user consent.

Potential to Lock Out the Victim: The attacker can change the password and prevent the victim from accessing their own account, leading to a potential denial of service.

Stealing Funds: Since the site allows money transfers, the attacker can transfer all funds from the compromised accounts to their own, effectively stealing money from the victims.
