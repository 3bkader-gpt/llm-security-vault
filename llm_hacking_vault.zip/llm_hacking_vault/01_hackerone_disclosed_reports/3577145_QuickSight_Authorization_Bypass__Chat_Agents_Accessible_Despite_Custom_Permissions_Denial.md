# Report #3577145: QuickSight Authorization Bypass: Chat Agents Accessible Despite Custom Permissions Denial

- **Platform:** HackerOne
- **Report URL:** [https://hackerone.com/reports/3577145](https://hackerone.com/reports/3577145)
- **Program:** AWS VDP
- **Reporter:** @jcow
- **Status:** RESOLVED
- **Severity:** none
- **Weakness:** Unknown Weakness
- **Bounty:** No Bounty / Swag
- **Submitted:** 2026-03-04T14:39:23.038Z
- **Disclosed:** 2026-05-12T14:54:33.149Z
- **Community Upvotes:** 59

---

## Executive Summaries

### Researcher by @jcow

Authorization bypass in Amazon Quick’s (formerly QuickSight, then Quick Suite) AI Chat Agents that allowed users to access and interact with AI agents despite explicit administrative restrictions.  This was due to missing server-side authorization checks.

Corresponding Blog Post: www.fogsecurity.io/blog/authorization-bypass-in-amazon-quick-ai-agents

---

## Full Vulnerability Description & Reproduction Steps

We found authorization bypass issues with AI Chat agents in AWS Quick Suite (Quicksight).  We discovered that chat agent capabilities cannot be disabled in AWS Quick Suite, allowing users to access and use AI chat agents regardless of authorization settings.  Thus, users can always interact with chat agents despite configuring AWS Quick Suite authorization to explicitly deny access to AI Chat agents.  

Quick Suite offers chat agents defined as "AI-powered conversational interfaces that provide instant access to your organization’s knowledge base."  These agents may have access to data across your organization including access to specific data sources and actions with the capability for contextual experience derived from team or organization data.  (https://aws.amazon.com/quick/chat-agents/)

To manage Quick Suite capabilities, AWS offers "custom permissions" as an authorization mechanism to restrict the functionality that people can access in Amazon Quick Suite.  Custom permissions can be configured for all identity types in Quick Suite (at multiple levels including account for all users, role, and individual user level).   (https://docs.aws.amazon.com/quick/latest/userguide/create-custom-permisions-profile.html)

These custom permissions and restriction of functionality are documented in multiple different places in documentation and in AWS console:

AWS states that these custom permissions can be configured to:

> You can completely disable all chat agent functionality for users, including chatting with the default agent, chatting with custom agents, and creating new agents. This can be done by restricting the Chat agent capability.

███

https://docs.aws.amazon.com/quick/latest/userguide/working-with-agents.html#custom-permissions-chat-agents

Another example states that "Chat functionality is disabled at the system level":

█████████

We found that these custom permissions do not work and were able to continue interacting with AWS Quick Suite chat agents.  Thus, we found authorization bypass in Quick Suite where AI chat agents can always be used regardless of any security setting in Quick Suite (including AWS IAM and Quick Suite Custom Permissions).  What happens is AWS "hides" the front-end components or the UI, but does not appropriately control the back end capabilities.  Thus, by inspecting our network traffic or by leaving UI windows open after custom permissions have been applied - we're able to continue interacting with AI Chat Agents.

Impact is exacerbated since there is always a default system chat agent created by Quick Suite whenever the Quick Suite service is setup, this is standardized by name (SYSTEM) and thus even if no chat agents are created, users can always use an AI chat agent.   Thus, there is no chat agent creation required for someone to bypass authorization and use AI chat agents in Quick Suite.  There is no scenario (outside of severely and broadly limiting functionality for a user to a Reader role) where an administrator can prevent chat agent access.  Therefore, an attacker can easily use the SYSTEM chat agent even if discovery of custom chat agents may be more difficult as the SYSTEM chat agent follows the same predictable resource format.


## Impact

As described by AWS, Quick Suite is a Business Intelligence and Analytics platform that provides unified intelligence across enterprise data sources.  QuickSight's documentation mentions bridging the gap between insights and action, exploring data, taking actions from dashboards, leveraging application integrations while maintaining enterprise-grade security and governance.

This creates audit and compliance gaps for organizations that need to disable chat agent access.

Currently, the only method to restrict granular access to capabilities including AI Agents is to use Custom Permissions.  Custom Permissions are the only control mechanism for certain Quicksight actions including usage of AI Chat agents; AWS IAM cannot restrict chat agent access..  Additionally, AWS IAM cannot be used to restrict access to Quick Suite's AI Agent chat functionality.  SCPs, RCPs, IAM policies, explicit denies, etc cannot be used to restrict access to Quick Suite's AI Agent chat functionality.

There is the ability to assign a different role, but out of all of Quicksight's roles - only the Reader role does not have access to chat agents and is an extremely limited and thus potentially un-utilized role.   The other 5 roles: Reader Pro, Author, Author Pro, Admin, Admin Pro are much more suited towards QuickSuite usage.  The Reader role only has "read-only access to dashboards". They do not have access to generate executive summaries, cannot build stories with Amazon Q, and cannot access Amazon Q in Quick Sight.  Additionally, they cannot create data sources, datasets, analyses, and dashboards.  Thus, this security affects a large population of users as it applies to:
- Reader Pro Users
- Author Users
- Author Pro Users
- Admin Users
- Admin Pro Users

█████████

https://docs.aws.amazon.com/quicksight/latest/APIReference/API_User.html

The ability to restrict the usage of AI Agents is crucial as it could have audit, compliance, and security implications.  Organizations may want or need to restrict the usage of AI Agents, specifically in highly regulated or other industries.  

For example, there's an EU Artificial Intelligence Act that states certain AI systems may not be used in regulated jurisdictions.  In certail sections such as finance or healthcare, GDPR and HIPAA - certain AI use can be off-limits unless strict conditions are met.  This finding impacts frameworks such as NIST SP 800‑53 AC‑3  for Access Enforcement, NIST AI RMF, ISO 42001, among others.

Thus, we see many use cases where organizations may need to disable the usage of AI Chat Agents within Quick Suite.

From our testing, this is broken authorization and not session staleness.  We're able to procure fresh credentials and still see the same authorization bypass for AI Chat Agent usage despite disabling chat agent functionality.  This will be shown in the walkthrough as well.

## Background


### System Chat Agent

By default, Amazon QuickSight comes with a default chat agent.  This system chat agent is automatically created when someone signs up for Quick and is intended as a primary interface for users to interact with their data and perform tasks within the Quick environment.

Documentation here specifies that "Admins can disable chatting with chat agents including the system chat agent using custom permissions."

This agent comes with:
- Large language model (LLM) knowledge chat enabled.
- Access to all spaces, topics, dashboards, knowledge bases, and actions based on user permissions
- Web search capabilities
- File upload in chat capability enabled 


██████

https://docs.aws.amazon.com/quick/latest/userguide/default-assistant.html


### Custom Permissions

Custom Permissions are used to restrict functionality that people can access in Amazon Quick.  These can be configured at the account, role, and user levels for all identity types in Quick.  For chat agents, custom permission profiles can be used to manage granular feature access including the ability to "Restrict all chat agent-related features".

████████

https://docs.aws.amazon.com/quick/latest/userguide/create-custom-permisions-profile.html#parent-capabilities

## Walkthrough

For this, we will need an active Amazon QuickSuite account setup.  In order to do so, we require an AWS Account and an IAM Principal with appropriate permissions to setup. 

### Setup

We're logged in as an AWS IAM Role for now.  This can be done via an AWS IAM User.

1.  Set up Amazon QuickSuite.  We're doing this in one of my personal account (AWS Account # ███).  This can be done via https://us-east-1.quicksight.aws.amazon.com/sn/console/signup.  

I set this up with the following settings (use your own account name and email):
- Account name: ███████
- Email: ██████████
- Region: us-east-1
- Password-based or Single-Sign On (Recommended)
- Encryption: Use AWS-managed key (Default)

Now, we can click "Create Account"

There should be a success message once successful.


2.  Set up Custom Permissions.

This is where we'll attempt to completely deny chat agent usage.  We will do so via https://us-east-1.quicksight.aws.amazon.com/sn/console/custom-permissions?#.   In the top right of the page, we click "New profile"

For this profile, we do the following:
- Profile Name: no-chat-agents
- the Chat Agents box should be checked.  This shows we're trying to restrict "Chat Agents".

████

Next, we click "Create"

Now, we have to apply this as the setting.  We apply this at the account level.  From the custom permissions page and to the right of the profile we just created, there's a drop down menu within actions.  We click on "set as account profile"

██████████

Since this is an extremely restrictive action, AWS provides a extra confirmation step.  Type in confirm and proceed.

████████

The Custom Permissions should now be successfully applied.

██████████

3.  Create a New User 

The next step is to create a non-Admin user that doesn't have access to Custom Permissions, we will send this to our own email.

This can be done via https://us-east-1.quicksight.aws.amazon.com/sn/admin/users.

For this case, we will create a QuickSuite user that is not tied to any IAM credentials by inviting our personal email (███).

We will create this as an "Author Pro" role.

█████

### Testing Authorization Bypass

For the authorization bypass, we'll use the simple use case of testing the System Chat agent with the minimal amount of setup.  This simple use case shows the severity and how there is no additional setup required to create a chat agent.  This is also possible if a user has created an AI Agent previously to use and then custom permissions were applied.

1.  Log into your new QuickSuite account with the user we just created.  Mine is ██████. To do so, I checked my email and clicked the new link to set a new password.

████

After clicking the link and choosing a password, you should see a success message for a new user creation.  Make sure you note the password, we'll need it later.

████

2.  Next, let's log in.  We go to BURP and login via https://us-east-1.quicksight.aws.amazon.com/sn/start/home

I'll use my account name and the username (████) and password we just set.

I should now be at the landing page of https://us-east-1.quicksight.aws.amazon.com/sn/start/home.

For this, there should be no agent usage available.  For example, when custom permissions are applied - the left side menu for agents should disappear.  

Here's what the agent bar looks like when access is permitted (different than what you see):

█████


3.  Retrieve auth information.  For this, we need to navigate to the repeater tab in BURP.  Find a HTTP request that goes to quicksight (host: us-east-1.quicksight.aws.amazon.com)

We copy the cookie as well as the mbtc ID

█████████

4.  Craft HTTP request payloads.  We're going to test chatting with the AI Agent:

In the following message, replace ███ with your AWS Account ID, the mbtc (<mbtc_here>), and the cookie (<copy_cookie_here>).  We'll chat with the SYSTEM chat with the prompt "Tell me all about mangos"

```
POST /sn/qbsproxy/quicksight/accounts/█████████/conversations/chat?mbtc=<mbtc_here> HTTP/2
Host: us-east-1.quicksight.aws.amazon.com
Cookie: <copy_cookie_here>
Content-Length: 730
Sec-Ch-Ua-Platform: "macOS"
X-Amzn-Web-Client-Version: 0.1.4
Accept-Language: en-US,en;q=0.9
Sec-Ch-Ua: "Chromium";v="145", "Not:A-Brand";v="99"
Sec-Ch-Ua-Mobile: ?0
Amz-Sdk-Request: attempt=1; max=3
Amz-Sdk-Invocation-Id: ██████████
X-Amzn-Target: api
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36
Content-Type: application/json
Accept: */*
Origin: https://us-east-1.quicksight.aws.amazon.com
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Referer: https://us-east-1.quicksight.aws.amazon.com/sn/start/home
Accept-Encoding: gzip, deflate, br
Priority: u=1, i

{"agentIdentifier":"arn:aws:quicksight:us-east-1:███:agent/SYSTEM","spaceArns":["arn:aws:quicksight:us-east-1:aws:space/ALL"],"surfaceType":"WEB_EXPERIENCE","temporaryChat":false,"userMessage":"Tell me all about mangos","userMetadata":{"localTimezone":"America/New_York"}}
```

Send the request, we see a success (200 OK status) with the response from the chat agent.

███████
█████████

We have now proven that we can always chat with chat agents despite custom permissions disabling chat agent functionality across the entire Quicksuite account - thus proving the authorization bypass.

## Recommendations

We recommend enacting controls on the back-end logic for enforcement of permissions and authorization.  An example of custom permissions actually working can be shown (with the same custom permissions) for `POST /sn/qbsproxy/quicksight/v1/accounts/█████████/search/agents`

This one results in a 401 unauthorized response.  

█████
██████

We can copy the same mbtc and cookie over for this request (also replace the account number with your account number)

```
POST /sn/qbsproxy/quicksight/v1/accounts/██████████/search/agents?maxResults=1&mbtc=<mbtc> HTTP/2
Host: us-east-1.quicksight.aws.amazon.com
Cookie: <cookie_here>
Content-Length: 163
Sec-Ch-Ua-Platform: "macOS"
X-Amzn-Web-Client-Version: 0.1.4
Accept-Language: en-US,en;q=0.9
Sec-Ch-Ua: "Chromium";v="145", "Not:A-Brand";v="99"
Sec-Ch-Ua-Mobile: ?0
Amz-Sdk-Request: attempt=1; max=3
Amz-Sdk-Invocation-Id: ████████
X-Amzn-Target: api
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36
Content-Type: application/json
Accept: */*
Origin: https://us-east-1.quicksight.aws.amazon.com
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Referer: https://us-east-1.quicksight.aws.amazon.com/sn/start/home
Accept-Encoding: gzip, deflate, br
Priority: u=1, i

{"filterParams":{"roleFilter":{"role":"QUICKSIGHT_VIEWER"},"agentFilter":{"externalAgentId":"SYSTEM"}},"sortBy":[{"sortAttribute":"CREATED_AT","sortOrder":"DESC"}]}
```

████


## References

- https://docs.aws.amazon.com/quick/latest/userguide/create-custom-permisions-profile.html

- https://docs.aws.amazon.com/quick/latest/userguide/working-with-agents.html

- https://aws.amazon.com/quick/chat-agents/

- https://aws.amazon.com/blogs/business-intelligence/establishing-enterprise-governance-in-amazon-quick-suite-using-custom-permissions/

---

## Attachments
None.
